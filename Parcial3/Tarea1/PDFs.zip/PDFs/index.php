<?php
require('fpdf186/fpdf.php');

$pdf = new FPDF();//creamos un objeto
$pdf->AddPage();//insertamos una pagina
$pdf->SetFont('Arial','B',16);//configuro tipografia
$pdf->SetFont('Courier','I',14);
$pdf->Cell(0,10, 'Centro de Estudios Tecnologicos Industriales y de Servicios No.084');//Primera frase
$pdf->Ln(10);
$pdf->SetFont('Arial','B',16);
$pdf->Cell(40,10,utf8_decode('Desarrolla Aplicaciones web con conexión a base de datos'));//segunda frase
$pdf->Ln(10);
$pdf->SetFont('Courier','I',16);
$pdf->Cell(40,10,utf8_decode('Sánchez Basurto Alexa'));//tercera frase
$pdf->Output();//cierro el PDF y lo abro
?>
