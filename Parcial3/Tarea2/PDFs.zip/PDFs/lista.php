<?php
require('fpdf186/fpdf.php');

$pdf = new FPDF();
$pdf->AddPage();

// Título de la lista
$pdf->SetFont('Arial', 'B', 30);
$pdf->SetTextColor(204, 153, 255); 
$pdf->Cell(0, 10, utf8_decode('Lista de productos <3'), 0, 1, 'C'); 
$pdf->Ln(10); 

$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(51, 0, 102);

// Encabezados de columnas
$pdf->SetFont('Arial', 'B', 15);
$pdf->Cell(60, 10, 'Producto', 1, 0, 'C');
$pdf->Cell(80, 10,utf8_decode('Descripción'), 1, 0, 'C');
$pdf->Cell(30, 10, 'Precio', 1, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(0, 0, 0);

// Lista de productos
$productos = [
    ["Lapiz", "Lapiz HB", "$5.00"],
    ["Pluma", "Pluma de tinta azul", "$7.00"],
    ["Cuaderno", "Cuaderno de 100 hojas", "$25.00"],
    ["Borrador", "Borrador blanco", "$3.00"],
    ["Tijeras", "Tijeras escolares", "$15.00"],
    ["Pegamento", "Pegamento en barra", "$10.00"],
    ["Marcador", "Marcador permanente negro", "$20.00"],
    ["Regla", "Regla de 30 cm", "$12.00"],
    ["Folder", "Folder tamaño carta", "$8.00"],
    ["Calculadora", "Calculadora básica", "$150.00"]
];


foreach ($productos as $producto) {
    $pdf->Cell(60, 10, utf8_decode($producto[0]), 1); // Columna de nombre de producto
    $pdf->Cell(80, 10, utf8_decode($producto[1]), 1); // Columna de descripción
    $pdf->Cell(30, 10, $producto[2], 1, 1, 'R');      // Columna de precio alineado a la derecha
}

$pdf->Output();
?>

